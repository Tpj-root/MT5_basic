Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:selected = ""

$form = New-Object System.Windows.Forms.Form
$form.Text = "MetaTrader 5 Configure"
$form.Size = New-Object System.Drawing.Size(420, 160)
$form.StartPosition = "CenterScreen"
$form.TopMost = $true

$label = New-Object System.Windows.Forms.Label
$label.Text = "Select MetaTrader 5 executable (terminal64.exe)"
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(10, 8)
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10, 28)
$textBox.Width = 300
$form.Controls.Add($textBox)

$buttonBrowse = New-Object System.Windows.Forms.Button
$buttonBrowse.Text = "Browse"
$buttonBrowse.Location = New-Object System.Drawing.Point(318, 26)
$buttonBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = "MetaTrader 5 (terminal64.exe;terminal.exe)|terminal64.exe;terminal.exe|Executables (*.exe)|*.exe"
    $dlg.InitialDirectory = $env:ProgramFiles
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $textBox.Text = $dlg.FileName
    }
})
$form.Controls.Add($buttonBrowse)

$buttonOK = New-Object System.Windows.Forms.Button
$buttonOK.Text = "OK"
$buttonOK.Location = New-Object System.Drawing.Point(120, 80)
$buttonOK.Add_Click({
    if ([string]::IsNullOrWhiteSpace($textBox.Text) -or -not (Test-Path -LiteralPath $textBox.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please select a valid MetaTrader executable.")
    } else {
        $script:selected = $textBox.Text
        $form.Close()
    }
})
$form.Controls.Add($buttonOK)

$buttonCancel = New-Object System.Windows.Forms.Button
$buttonCancel.Text = "Cancel"
$buttonCancel.Location = New-Object System.Drawing.Point(210, 80)
$buttonCancel.Add_Click({ $form.Close() })
$form.Controls.Add($buttonCancel)

$form.Add_Shown({ $form.Activate() })
[void]$form.ShowDialog()

# Only this line goes to stdout, which the .bat captures
Write-Output $script:selected
