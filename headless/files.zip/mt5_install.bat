@echo off
setlocal EnableExtensions
set "SVC=MT5Service"

REM ---- 1. Must be Administrator ----
net session >nul 2>&1
if errorlevel 1 (
    echo ERROR: Please run this script as Administrator.
    pause
    exit /b 1
)

REM ---- 2. Paths and architecture ----
set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"

set "OS_ARCH=x86"
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" set "OS_ARCH=x64"
if defined PROCESSOR_ARCHITEW6432 set "OS_ARCH=x64"

set "NSSM=%BASE_DIR%\bin\%OS_ARCH%\nssm.exe"
set "INI=%BASE_DIR%\common.ini"
set "LOG_DIR=%BASE_DIR%\logs"

if not exist "%NSSM%" goto :no_nssm
if not exist "%INI%" goto :no_ini

REM ---- 3. Pick terminal64.exe ----
set "FOUND_EXE="
for /f "usebackq delims=" %%i in (`powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%BASE_DIR%\selectfile.ps1"`) do set "FOUND_EXE=%%i"
if not defined FOUND_EXE goto :cancelled
if not exist "%FOUND_EXE%" goto :bad_exe

for %%F in ("%FOUND_EXE%") do set "FOUND_DIR=%%~dpF"
if "%FOUND_DIR:~-1%"=="\" set "FOUND_DIR=%FOUND_DIR:~0,-1%"

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

REM ---- 4. Remove an old copy of the service, if any ----
sc query %SVC% >nul 2>&1
if not errorlevel 1 (
    echo Existing %SVC% found - removing it first...
    "%NSSM%" stop %SVC% >nul 2>&1
    "%NSSM%" remove %SVC% confirm >nul 2>&1
)

REM ---- 5. Install and configure ----
echo Installing %SVC%
echo   EXE : %FOUND_EXE%
echo   DIR : %FOUND_DIR%
echo   INI : %INI%

"%NSSM%" install %SVC% "%FOUND_EXE%"
if errorlevel 1 goto :fail
"%NSSM%" set %SVC% AppDirectory "%FOUND_DIR%"
"%NSSM%" set %SVC% AppParameters "/config:\"%INI%\" /portable"
"%NSSM%" set %SVC% DisplayName "MT5Service"
"%NSSM%" set %SVC% Description "MetaTrader 5 running headless as a Windows service"
"%NSSM%" set %SVC% ObjectName LocalSystem
"%NSSM%" set %SVC% Start SERVICE_AUTO_START
"%NSSM%" set %SVC% Type SERVICE_INTERACTIVE_PROCESS
"%NSSM%" set %SVC% AppExit Default Restart
"%NSSM%" set %SVC% AppRestartDelay 5000
"%NSSM%" set %SVC% AppStdout "%LOG_DIR%\mt5_out.log"
"%NSSM%" set %SVC% AppStderr "%LOG_DIR%\mt5_err.log"
"%NSSM%" set %SVC% AppRotateFiles 1
"%NSSM%" set %SVC% AppRotateBytes 5000000

"%NSSM%" start %SVC%
echo.
echo Done. Check services.msc or run: mt5_ctl.bat status
pause
exit /b 0

:no_nssm
echo ERROR: NSSM not found: %NSSM%
pause
exit /b 1

:no_ini
echo ERROR: common.ini not found: %INI%
pause
exit /b 1

:cancelled
echo No file selected. Cancelled.
pause
exit /b 1

:bad_exe
echo ERROR: File does not exist: %FOUND_EXE%
pause
exit /b 1

:fail
echo ERROR: nssm install failed.
pause
exit /b 1
