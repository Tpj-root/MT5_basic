@echo off
setlocal EnableExtensions
REM Usage: mt5_ctl.bat start | stop | restart | status | remove
set "SVC=MT5Service"

net session >nul 2>&1
if errorlevel 1 (
    echo ERROR: Please run this script as Administrator.
    pause
    exit /b 1
)

set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"
set "OS_ARCH=x86"
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" set "OS_ARCH=x64"
if defined PROCESSOR_ARCHITEW6432 set "OS_ARCH=x64"
set "NSSM=%BASE_DIR%\bin\%OS_ARCH%\nssm.exe"

if not exist "%NSSM%" (
    echo ERROR: NSSM not found: %NSSM%
    exit /b 1
)

if /i "%~1"=="start"   ( "%NSSM%" start %SVC%   & exit /b )
if /i "%~1"=="stop"    ( "%NSSM%" stop %SVC%    & exit /b )
if /i "%~1"=="restart" ( "%NSSM%" restart %SVC% & exit /b )
if /i "%~1"=="status"  ( "%NSSM%" status %SVC%  & exit /b )
if /i "%~1"=="remove"  (
    "%NSSM%" stop %SVC%
    "%NSSM%" remove %SVC% confirm
    exit /b
)

echo Usage: mt5_ctl.bat start ^| stop ^| restart ^| status ^| remove
exit /b 1
